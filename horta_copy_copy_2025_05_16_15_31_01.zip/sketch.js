let carrinho;
let produtos = [];
let coletados = [];
let maxProdutos = 6;
let gameState = "compra";
let selecionado = null;

let emojis = ["🍎", "🍇", "🍓", "🍉", "🥕", "🍍", "🍅", "🥬", "🌽", "🥑"];

function setup() {
  createCanvas(800, 400);
  textAlign(CENTER, CENTER);
  textSize(32);

  carrinho = new Carrinho();

  // Criar produtos nas prateleiras
  let xStart = 100;
  let yStart = 80;
  let espaco = 80;

  for (let i = 0; i < 10; i++) {
    let x = xStart + (i % 5) * espaco;
    let y = yStart + floor(i / 5) * espaco;
    produtos.push(new Produto(x, y, random(emojis)));
  }
}

function draw() {
  background(240, 240, 200);

  drawPrateleiras();

  for (let p of produtos) {
    p.show();
  }

  carrinho.show();

  fill(50);
  textSize(18);
  text(`Produtos no carrinho: ${coletados.length} / ${maxProdutos}`, 160, 30);

  if (gameState === "fim") {
    background(240, 240, 200);
    fill(20, 120, 20);
    textSize(24);
    text("🛒 Obrigado pela compra no mercadinho rural!", width / 2, 60);
    textSize(32);
    text(coletados.join(" "), width / 2, height / 2);
  }
}

function drawPrateleiras() {
  fill(180, 140, 90);
  rect(80, 60, 360, 20);
  rect(80, 140, 360, 20);
}

function mousePressed() {
  for (let p of produtos) {
    if (!p.pego && p.isMouseOver()) {
      selecionado = p;
      break;
    }
  }
}

function mouseDragged() {
  if (selecionado) {
    selecionado.x = mouseX;
    selecionado.y = mouseY;
  }
}

function mouseReleased() {
  if (selecionado && !selecionado.pego) {
    if (selecionado.overCarrinho(carrinho)) {
      selecionado.pego = true;
      coletados.push(selecionado.emoji);
    }
    selecionado = null;
  }
}

function keyPressed() {
  if (key === ' ' && coletados.length >= maxProdutos) {
    gameState = "fim";
  }
}

class Produto {
  constructor(x, y, emoji) {
    this.x = x;
    this.y = y;
    this.emoji = emoji;
    this.tamanho = 32;
    this.pego = false;
  }

  show() {
    if (!this.pego) {
      textSize(this.tamanho);
      text(this.emoji, this.x, this.y);
    }
  }

  isMouseOver() {
    return dist(mouseX, mouseY, this.x, this.y) < 20;
  }

  overCarrinho(carrinho) {
    return collideRectCircle(carrinho.x - 20, carrinho.y - 20, 40, 40, this.x, this.y, 20);
  }
}

class Carrinho {
  constructor() {
    this.x = 700;
    this.y = height - 60;
  }

  show() {
    textSize(40);
    text("🛒", this.x, this.y);
  }
}
